# Kakao Emoticon Profit System v90

## v90 핵심

v90은 v89의 자동 이전 버전 정리 기능을 유지하면서, 이모티콘 출력 방식을 초보자 기준으로 더 단순화했습니다.

- 정지형 최종 후보: PNG 32개
- 움직이는형 최종 후보: GIF 24개
- JPG: 제출용이 아닌 확인용 미리보기
- 최종 출력 폴더: `static_png_submit`, `animated_gif_submit`, `preview_jpg`, `metadata`
- 기본 UI: 5개 큰 흐름 유지
- 고급 세부 기능: 고급 메뉴 안에 유지
- v89 이하 이전 버전: 설치 성공 후 사용자 데이터 후보 백업 뒤 자동 정리

## 빠른 실행

1. ZIP을 `C:\KakaoEmoticonV90` 같은 새 폴더에 압축 해제합니다.
2. `47_V90_SIMPLE_PNG_GIF_OUTPUT_CHECK.bat`를 먼저 실행합니다.
3. 포터블 설치는 `00_STEP_2_PORTABLE_INSTALL_NOW.bat`를 실행합니다.
4. 실행은 `00_STEP_3_START_PROGRAM.bat`를 사용합니다.

## 설치마법사 EXE 생성

Windows PC에 Inno Setup이 설치되어 있으면 아래 파일을 실행하세요.

```bat
00_DOUBLE_CLICK_THIS_FIRST_BUILD_SETUP_EXE.bat
```

생성 위치:

```text
installer\Output\KakaoEmoticonSetup_v90.exe
```

현재 Linux 기반 검증 환경에서는 Inno Setup EXE 컴파일을 직접 수행할 수 없습니다.

## 데이터 보호

이전 버전 정리 전 다음 후보를 백업합니다.

- outputs / output / user_data / data / settings / reports / backups / exports / projects
- DB / JSON / CSV / Excel / TXT / HTML / PNG / JPG / GIF / ZIP 파일

시스템 폴더와 현재 v90 이상 폴더는 정리 대상에서 제외됩니다.

## 출력 규칙

- `static_png_submit`: 안 움직이는 이모티콘 PNG 최종 후보
- `animated_gif_submit`: 움직이는 이모티콘 GIF 최종 후보
- `preview_jpg`: 눈으로 확인하기 위한 JPG 미리보기
- JPG는 제출용 ZIP과 분리됩니다.

## 안전 원칙

이 프로그램은 직접 창작 기반 이모티콘 제작 보조 도구입니다. 기존 캐릭터, 유명 캐릭터, 상표, 인기 이모티콘을 복제하거나 따라 만드는 기능은 제공하지 않습니다.
